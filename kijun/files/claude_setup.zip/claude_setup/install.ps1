﻿# 클로드 코드 설정 옮기기 (상태줄 + 대화 저장) — 2026-11-27
# 이 폴더 안에서 [설치.bat] 을 두 번 누르면 실행된다.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$cdir = Join-Path $env:USERPROFILE '.claude'
$sdir = Join-Path $cdir 'scripts'

# 1. 파이썬 찾기
$py = $null
foreach ($n in @('python', 'py')) {
    $c = Get-Command $n -ErrorAction SilentlyContinue
    if ($c -and $c.Source -notlike '*WindowsApps*') { $py = $c.Source; break }
}
if (-not $py) {
    Write-Host ''
    Write-Host '파이썬(Python)이 이 컴퓨터에 없습니다.' -ForegroundColor Red
    Write-Host 'https://www.python.org/downloads/ 에서 설치할 때 [Add python.exe to PATH] 에 체크하고, 설치 뒤 다시 실행해 주세요.'
    exit 1
}
Write-Host "파이썬 : $py"

# 2. 프로그램 두 개 복사
New-Item -ItemType Directory -Force $sdir | Out-Null
Copy-Item (Join-Path $here 'statusline.py') $sdir -Force
Copy-Item (Join-Path $here 'save_chat.py') $sdir -Force
Write-Host "복사 : $sdir"

# 3. settings.json 에 더하기 (있던 설정은 그대로 둠, 고치기 전 사본을 남김)
$sp = Join-Path $cdir 'settings.json'
if (Test-Path $sp) {
    Copy-Item $sp ($sp + '.bak_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $raw = [IO.File]::ReadAllText($sp, [Text.Encoding]::UTF8)
    if ($raw.Trim() -eq '') { $raw = '{}' }
} else { $raw = '{}' }
$s = $raw | ConvertFrom-Json

$pyq = $py -replace '\\', '/'
$slCmd = "`"$pyq`" -I `"" + ((Join-Path $sdir 'statusline.py') -replace '\\', '/') + "`""
$scCmd = "`"$pyq`" -I `"" + ((Join-Path $sdir 'save_chat.py') -replace '\\', '/') + "`""

$sl = [pscustomobject]@{ type = 'command'; command = $slCmd; padding = 0; refreshInterval = 60 }
if ($s.PSObject.Properties['statusLine']) { $s.statusLine = $sl } else { $s | Add-Member statusLine $sl }

if (-not $s.PSObject.Properties['hooks']) { $s | Add-Member hooks ([pscustomobject]@{}) }
$stop = @()
if ($s.hooks.PSObject.Properties['Stop']) { $stop = @($s.hooks.Stop) }
$has = $false
foreach ($g in $stop) { foreach ($h in @($g.hooks)) { if ($h.command -like '*save_chat.py*') { $h.command = $scCmd; $has = $true } } }
if (-not $has) {
    $stop += [pscustomobject]@{ hooks = @([pscustomobject]@{ type = 'command'; command = $scCmd; timeout = 30 }) }
}
if ($s.hooks.PSObject.Properties['Stop']) { $s.hooks.Stop = $stop } else { $s.hooks | Add-Member Stop $stop }

$json = $s | ConvertTo-Json -Depth 30
[IO.File]::WriteAllText($sp, $json, (New-Object Text.UTF8Encoding($false)))
Write-Host "설정 : $sp"

# 4. 시험
$test = '{"workspace":{"current_dir":"C:/test/school"},"context_window":{"context_window_size":1000000,"used_percentage":14,"current_usage":{"input_tokens":1000,"cache_read_input_tokens":139000,"output_tokens":0}},"rate_limits":{"five_hour":{"used_percentage":2,"resets_at":1795801200}}}'
Write-Host ''
Write-Host '상태줄 시험 :'
$test | & $py -I (Join-Path $sdir 'statusline.py')
Write-Host ''
Write-Host '끝났습니다. 클로드 코드를 [새로] 열면 적용됩니다.' -ForegroundColor Green
