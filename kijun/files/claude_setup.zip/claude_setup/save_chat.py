# 대화 저장 : 클로드가 대답을 마칠 때마다 이 대화를 "실행한 폴더\_클로드대화\" 에 읽기 쉬운 .md 로 저장 (2026-11-27)
import sys, json, os, io, datetime
try:
    h = json.loads(sys.stdin.buffer.read().decode("utf-8-sig", "replace"))
    tp, cwd, sid = h.get("transcript_path"), h.get("cwd") or os.getcwd(), h.get("session_id", "x")
    if not tp or not os.path.exists(tp): sys.exit(0)
    lines, start, last = [], None, None
    for raw in open(tp, encoding="utf-8", errors="replace"):
        try: e = json.loads(raw)
        except Exception: continue
        if e.get("type") not in ("user", "assistant") or e.get("isSidechain") or e.get("isMeta"): continue
        ts = e.get("timestamp", "")
        try: t = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone()
        except Exception: t = None
        if t and not start: start = t
        c = (e.get("message") or {}).get("content")
        texts = []
        if isinstance(c, str): texts.append(c)
        elif isinstance(c, list):
            for b in c:
                if not isinstance(b, dict): continue
                if b.get("type") == "text": texts.append(b.get("text", ""))
                elif b.get("type") == "tool_use":
                    i = b.get("input") or {}
                    desc = i.get("description") or i.get("file_path") or i.get("pattern") or i.get("skill") or ""
                    texts.append(f"> 🔧 {b.get('name')} {str(desc)[:150]}")
        texts = [x for x in texts if x.strip() and not x.lstrip().startswith("<")]
        if not texts: continue
        who = "🙋 사장님" if e["type"] == "user" else "🤖 클로드"
        hm = t.strftime("%m-%d %H:%M") if t else ""
        if lines and last == who: lines.append("\n\n".join(texts) + "\n")
        else: lines.append(f"### {who} · {hm}\n\n" + "\n\n".join(texts) + "\n")
        last = who
    if not lines: sys.exit(0)
    start = start or datetime.datetime.now()
    out = os.path.join(cwd, "_클로드대화")
    os.makedirs(out, exist_ok=True)
    fn = os.path.join(out, start.strftime("%Y%m%d_%H%M") + "_" + sid[:8] + ".md")
    head = f"# 클로드 대화 — {start.strftime('%Y-%m-%d %H:%M')} 시작\n\n- 폴더 : {cwd}\n- 원본 : {tp}\n\n---\n\n"
    tmp = fn + ".tmp"
    open(tmp, "w", encoding="utf-8").write(head + "\n".join(lines))
    os.replace(tmp, fn)
except Exception:
    pass
