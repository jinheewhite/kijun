# 상태줄 : 아이디 · 폴더 · 5시간 사용 % · 갱신 · 이번주 사용 % · 초기화 (2026-11-27)
import sys, json, os, io, datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
raw = sys.stdin.buffer.read().decode("utf-8-sig", "replace")
try: d = json.loads(raw)
except Exception: d = {}
try: open(os.path.expanduser("~/.claude/scripts/statusline_last.json"), "w", encoding="utf-8").write(raw)
except Exception: pass

def g(o, *ks):
    for k in ks:
        if not isinstance(o, dict): return None
        o = o.get(k)
    return o

def when(v):
    if v in (None, ""): return ""
    try:
        if isinstance(v, (int, float)) or str(v).isdigit():
            t = datetime.datetime.fromtimestamp(float(v) / (1000 if float(v) > 1e12 else 1))
        else:
            t = datetime.datetime.fromisoformat(str(v).replace("Z", "+00:00")).astimezone()
        yo = "월화수목금토일"[t.weekday()]
        ap = "오전" if t.hour < 12 else "오후"
        h = t.hour % 12 or 12
        return f"{t.month}/{t.day}({yo}) {ap} {h}:{t.minute:02d}"
    except Exception: return str(v)

parts = []
try:
    acc = json.load(open(os.path.expanduser("~/.claude.json"), encoding="utf-8")).get("oauthAccount") or {}
    em = acc.get("emailAddress") or ""
    parts.append("👤 " + (em.split("@")[0] if em else "로그인 전"))
except Exception:
    parts.append("👤 ?")
cwd =g(d, "workspace", "current_dir") or d.get("cwd") or os.getcwd()
parts.append("📁 " + (os.path.basename(cwd.rstrip("/\\")) or cwd))

rl = d.get("rate_limits") or {}
for key, head, tail in (("five_hour", "사용", "갱신"), ("seven_day", "이번주", "초기화")):
    r = rl.get(key)
    if not isinstance(r, dict): continue
    p = r.get("used_percentage", r.get("utilization"))
    s = f"{head} {p:.0f}% 사용됨." if isinstance(p, (int, float)) else head
    w = when(r.get("resets_at"))
    if w: s += f" {w} {tail}"
    parts.append(s)
if not rl:
    parts.append("사용량 : 첫 대답 뒤에 나옴")

print(" / ".join(parts))
