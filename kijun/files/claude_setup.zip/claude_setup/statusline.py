# 상태줄 : 폴더 · 대화 토큰 · 5시간 사용량 % · 갱신 시각 (2026-11-27)
import sys, json, os, io, datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
raw = sys.stdin.buffer.read().decode("utf-8-sig", "replace")
try: d = json.loads(raw)
except Exception: d = {}
try: open(os.path.expanduser("~/.claude/scripts/statusline_last.json"), "w", encoding="utf-8").write(raw)
except Exception: pass

def g(o, *ks):
    for k in ks:
        if not isinstance(o, dict): return None
        o = o.get(k)
    return o

def when(v):
    if v in (None, ""): return ""
    try:
        if isinstance(v, (int, float)) or str(v).isdigit():
            t = datetime.datetime.fromtimestamp(float(v) / (1000 if float(v) > 1e12 else 1))
        else:
            t = datetime.datetime.fromisoformat(str(v).replace("Z", "+00:00")).astimezone()
        now = datetime.datetime.now(t.tzinfo)
        s = f"{t.hour}시{t.minute:02d}분"
        return s if t.date() == now.date() else f"{t.month}/{t.day} " + s
    except Exception: return str(v)

parts = []
try:
    acc = json.load(open(os.path.expanduser("~/.claude.json"), encoding="utf-8")).get("oauthAccount") or {}
    em = acc.get("emailAddress") or ""
    parts.append("👤 " + (em.split("@")[0] if em else "로그인 전"))
except Exception:
    parts.append("👤 ?")
cwd =g(d, "workspace", "current_dir") or d.get("cwd") or os.getcwd()
parts.append("📁 " + (os.path.basename(cwd.rstrip("/\\")) or cwd))

cw = d.get("context_window") or {}
used = None
cu = cw.get("current_usage")
if isinstance(cu, dict):
    used = sum(int(cu.get(k) or 0) for k in ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens", "output_tokens"))
if not used:
    used = (cw.get("total_input_tokens") or 0) + (cw.get("total_output_tokens") or 0) or None
size = cw.get("context_window_size")
pct = cw.get("used_percentage")
if used:
    s = f"토큰 {used/1000:,.0f}k"
    if size: s += f"/{size/1000:,.0f}k"
    if pct is not None: s += f" ({pct:.0f}%)"
    elif size: s += f" ({used*100/size:.0f}%)"
    parts.append(s)

rl = d.get("rate_limits") or {}
r = rl.get("five_hour")
if isinstance(r, dict):
    p = r.get("used_percentage", r.get("utilization"))
    s = f"사용 {p:.0f}%" if isinstance(p, (int, float)) else ""
    w = when(r.get("resets_at"))
    if w: s += f" · {w} 갱신"
    parts.append(s.strip(" ·"))
else:
    parts.append("갱신시간 : 첫 대답 뒤에 나옴")

print(" / ".join(parts))
