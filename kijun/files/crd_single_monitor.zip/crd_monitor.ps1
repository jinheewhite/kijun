﻿# 크롬 원격 데스크톱 접속 중에는 "PC 화면만"(1번 모니터), 접속이 끊기면 다시 "확장"으로 되돌립니다.
#   설치: install.bat 실행  /  제거: uninstall.bat 실행
param([switch]$Install, [switch]$Uninstall)

$AppName  = 'CRD_SingleMonitor'
$AppDir   = Join-Path $env:LOCALAPPDATA $AppName
$Target   = Join-Path $AppDir 'crd_monitor.ps1'
$Shortcut = Join-Path ([Environment]::GetFolderPath('Startup')) "$AppName.lnk"
$PsExe    = Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe'

# 크롬 원격 데스크톱이 연결되어 있는 동안에만 실행되는 프로세스 이름
$CrdSessionProcess = 'remoting_desktop'

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class CrdTopology {
    [DllImport("user32.dll")]
    public static extern int SetDisplayConfig(uint numPathArrayElements, IntPtr pathArray,
                                              uint numModeInfoArrayElements, IntPtr modeInfoArray,
                                              uint flags);
}
"@

# Win+P 메뉴와 같은 동작: 0x1 = PC 화면만, 0x4 = 확장  (0x80 = 적용)
function Set-Topology([uint32]$Topology) {
    return ([CrdTopology]::SetDisplayConfig(0, [IntPtr]::Zero, 0, [IntPtr]::Zero, (0x80 -bor $Topology)) -eq 0)
}

function Stop-OtherCopies {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like '*crd_monitor.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

if ($Install) {
    Stop-OtherCopies
    New-Item -ItemType Directory -Force -Path $AppDir | Out-Null
    if ($PSCommandPath -ne $Target) { Copy-Item -LiteralPath $PSCommandPath -Destination $Target -Force }
    Unblock-File -LiteralPath $Target -ErrorAction SilentlyContinue

    $lnkArgs = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Target`""
    $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut($Shortcut)
    $lnk.TargetPath  = $PsExe
    $lnk.Arguments   = $lnkArgs
    $lnk.WindowStyle = 7
    $lnk.Save()

    Start-Process -FilePath $PsExe -ArgumentList $lnkArgs -WindowStyle Hidden
    Write-Host ''
    Write-Host '설치 완료: 지금부터 자동으로 동작하고, 컴퓨터를 켤 때마다 자동 실행됩니다.' -ForegroundColor Green
    Write-Host '  - 원격 접속 시  : PC 화면만(모니터 1대)'
    Write-Host '  - 접속 끊기면   : 확장(모니터 2대)으로 복구'
    exit
}

if ($Uninstall) {
    Stop-OtherCopies
    Remove-Item -LiteralPath $Shortcut -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $AppDir -Recurse -Force -ErrorAction SilentlyContinue
    [void](Set-Topology 0x4)
    Write-Host ''
    Write-Host '제거 완료: 자동 전환을 껐고, 모니터를 확장 모드로 되돌렸습니다.' -ForegroundColor Yellow
    exit
}

# ---- 감시 모드 (로그인 시 백그라운드로 실행) ----
$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, "Local\$AppName", [ref]$createdNew)
if (-not $createdNew) { exit }   # 이미 실행 중이면 종료

$singleApplied = $false
while ($true) {
    $connected = [bool](Get-Process -Name $CrdSessionProcess -ErrorAction SilentlyContinue)
    $locked    = [bool](Get-Process -Name 'LogonUI' -ErrorAction SilentlyContinue)

    if (-not $locked) {
        if ($connected -and -not $singleApplied) {
            Start-Sleep -Seconds 2
            if (Set-Topology 0x1) { $singleApplied = $true }      # PC 화면만
        }
        elseif (-not $connected -and $singleApplied) {
            if (Set-Topology 0x4) { $singleApplied = $false }     # 확장
        }
    }
    Start-Sleep -Seconds 3
}
